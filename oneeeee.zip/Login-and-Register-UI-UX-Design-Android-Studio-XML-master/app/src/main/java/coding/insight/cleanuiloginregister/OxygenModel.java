package coding.insight.cleanuiloginregister;

public class OxygenModel {

    String Name,Address,City,Number,Cylinders;

    public String getName() {
        return Name;
    }

    public String getAddress() {
        return Address;
    }

    public String getCity() {
        return City;
    }

    public String getNumber() {
        return Number;
    }

    public String getCylinders() {
        return Cylinders;
    }
}

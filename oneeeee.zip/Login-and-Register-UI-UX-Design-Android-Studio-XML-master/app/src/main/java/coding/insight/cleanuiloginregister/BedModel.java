package coding.insight.cleanuiloginregister;

public class BedModel {

    String Name,Address,City,Beds,Number;

    public String getName() {
        return Name;
    }

    public String getAddress() {
        return Address;
    }

    public String getCity() {
        return City;
    }

    public String getBeds() {
        return Beds;
    }

    public String getNumber() {
        return Number;
    }
}
